<?php
//conexao

$conexao = new mysqli("localhost","root","usbw","biblioteca");

if (!$conexao) {
	echo "Problemas com a conexão";
}

// Editora
function CadastrarEditora($nome){
	$sql = 'INSERT INTO tb_editora VALUES (null,"'.$nome.'")';
	$res = $GLOBALS['conexao']->query($sql);
	if ($res) {
		alert("Editora Cadastrada com sucesso");
	}else{
		alert("Erro ao cadastrar Editora");
	}
}

function ListarEditora($cd){
	$sql = 'SELECT * FROM tb_editora ';
	if($cd>0){
		$sql.=' WHERE cd_editora='.$cd;
	}
	$res = $GLOBALS['conexao']->query($sql);
	return $res;
}

function ExcluirEditora($cd){
	$sql = 'DELETE FROM tb_editora WHERE cd_editora='.$cd;
	$res = $GLOBALS	['conexao']->query($sql);
	if ($res) {
		alert("Editora Excluida com sucesso");
	}else{
		alert("Erro ao Excluir Editora");
	}
}

//------Fim Editora------------

//------------Funções

function alert($texto){
	echo '<script>
	alert("'.$texto.'");
	</script>';
}

//------------Fim Funções