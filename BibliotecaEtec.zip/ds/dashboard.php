<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Biblioteca</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <a href="../ds/dashboard.php">
        <h3>Sua<span>Mágica Biblioteca</span></h3>
        </a>
      </div>
      <div class="right_area">
        <a href="../Login/login.php" class="logout_btn">Sair</a>
      </div>
    </header>
    <!--header area end-->
    <!--mobile navigation bar start-->
    <div class="mobile_nav">
      <div class="nav_bar">
        <img src="1.png" class="mobile_profile_image" alt="">
        <i class="fa fa-bars nav_btn"></i>
      </div>
      <div class="mobile_nav_items">
        <a href="#"><i class="fas fa-desktop"></i><span>Pesquisar Livros</span></a>
        <a href="../ds/dashboardconfig.php"><i class="fas fa-cogs"></i><span>Configurações</span></a>
        <a href="#"><i class="fas fa-table"></i><span>Finanças</span></a>
        <a href="#"><i class="fas fa-th"></i><span>Feed</span></a>
        <a href="#"><i class="fas fa-info-circle"></i><span>Sobre nós</span></a>
        <a href="#"><i class="fas fa-sliders-h"></i><span>Outros</span></a>
      </div>
    </div>
    <!--mobile navigation bar end-->
    <!--sidebar start-->
    <div class="sidebar">
      <div class="profile_info">
        <img src="1.png" class="profile_image" alt="">
        <h4>Wizard User</h4>
      </div>
      <a href="#"><i class="fas fa-desktop"></i><span>Pesquisar Livros</span></a>
      <a href="../ds/dashboardconfig.php"><i class="fas fa-cogs"></i><span>Configurações</span></a>
      <a href="#"><i class="fas fa-table"></i><span>Finanças</span></a>
      <a href="#"><i class="fas fa-th"></i><span>Feed</span></a>
      <a href="#"><i class="fas fa-info-circle"></i><span>Sobre nós</span></a>
      <a href="#"><i class="fas fa-sliders-h"></i><span>Outros</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
      <div class="card">
        <p>"A culpa é das Estrelas"Hazel Grace Lancaster e Augustus Waters são dois adolescentes que se conhecem em um grupo de apoio para pacientes com câncer. Por causa da doença, Hazel sempre descartou a ideia de se envolver amorosamente, mas acaba cedendo ao se apaixonar por Augustus. Juntos, eles viajam para Amsterdã, onde embarcam em uma jornada inesquecível.</p>
      </div>
      <div class="card">
        <p>"Comer rezar Amar"Liz Gilbert pensa que ela tinha tudo que queria na vida: uma casa, um marido e uma carreira de sucesso. Porém recém-divorciada e de frente para um momento de mudança, ela se sente confusa sobre o que é importante em sua vida. Ousando sair da sua zona de conforto, Liz embarca em uma busca de auto-descoberta que a leva à Itália, à Índia e a Bali.</p>
      </div>
      <div class="card">
        <p>"Mein Kampf" é o título do livro de dois volumes de autoria de Adolf Hitler, no qual ele expressou suas ideias antissemitas, anticomunistas, antimarxistas, racialistas e nacionalistas de extrema-direita, então adotadas pelo Partido Nazista.</p>
      </div>
    </div>

    <script type="text/javascript">
    $(document).ready(function(){
      $('.nav_btn').click(function(){
        $('.mobile_nav_items').toggleClass('active');
      });
    });
    </script>

  </body>
</html>