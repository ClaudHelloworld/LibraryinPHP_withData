<?php
include('conexao.php');

if (isset($_GETT['editora'])) {
      $registro = ListarEditora($_GET['editora']);
      $editora = $registro->fetch_array();
      echo json_encode($editora);
}else{

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Biblioteca</title>
    <link rel="stylesheet" href="styleconfig.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>

    <script>
      $(document).on('click','.editar',function(){
        var cd = $(this).val();
        var url = 'http://localhost:8080/BibliotecaEtec/ds/dashboardconfig.php'+cd;
        $.ajax({

            url: url,
            type:'get',
            sucess: function(retorno){
              console.log(retorno);
            }

        });
      });
    </script>

 
<style>
<h2> {
       color: white;
}
</style>

  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <a href="../ds/dashboard.php">
        <h3>Sua<span>Mágica Biblioteca</span></h3>
        </a>
      </div>
      <div class="right_area">
        <a href="../Login/login.php" class="logout_btn">Sair</a>
      </div>
    </header>
    <!--header area end-->
    <!--mobile navigation bar start-->
    <div class="mobile_nav">
      <div class="nav_bar">
        <img src="1.png" class="mobile_profile_image" alt="">
        <i class="fa fa-bars nav_btn"></i>
      </div>
      <div class="mobile_nav_items">
        <a href="#"><i class="fas fa-desktop"></i><span>Pesquisar Livros</span></a>
        <a href="#"><i class="fas fa-cogs"></i><span>Configurações</span></a>
        <a href="#"><i class="fas fa-table"></i><span>Finanças</span></a>
        <a href="#"><i class="fas fa-th"></i><span>Feed</span></a>
        <a href="#"><i class="fas fa-info-circle"></i><span>Sobre nós</span></a>
        <a href="#"><i class="fas fa-sliders-h"></i><span>Configurações</span></a>
      </div>
    </div>
    <!--mobile navigation bar end-->
    <!--sidebar start-->
    <div class="sidebar">
      <div class="profile_info">
        <img src="1.png" class="profile_image" alt="">
        <h4>Wizard User</h4>
      </div>
      <a href="#"><i class="fas fa-desktop"></i><span>Pesquisar Livros</span></a>
      <a href="#"><i class="fas fa-cogs"></i><span>Configurações</span></a>
      <a href="#"><i class="fas fa-table"></i><span>Finanças</span></a>
      <a href="#"><i class="fas fa-th"></i><span>Feed</span></a>
      <a href="#"><i class="fas fa-info-circle"></i><span>Sobre nós</span></a>
      <a href="#"><i class="fas fa-sliders-h"></i><span>Configurações</span></a>
    </div>
    <!--sidebar end-->



  
      <div class="content">

    <div class="card">
   
   <font color="white"> <h2 class="text-center"> Gerenciador de Editoras</h2> </font>
     <font color="orange"> <h2 id="titulo2">Cadastrar Editora</h2> </font>
    
<!--Inicio Forms-->
    <div class="x">
    <div class="titulo2">    
        <form action="" method="post" id="cadastrar">
          <label for="nome">Nome da Editora:<hr></label>
          <input type="text" name="nome" id="nome">
          <button type="submit" name="" class="btn btn-default btn-block" style="background-color: green">Cadastrar</button>
        </form>
        <span>

          <?php
          if (isset($_POST['nome'])) {
            CadastrarEditora($_POST['nome']);
          }          
          ?>

        </span>
      </div>
    </div>
    <!--Fim Forms-->

</div>


    <div class="card">
   
     <font color="orange"> <h2 id="titulo2">Listar Editoras</h2> </font>
    
<!--Inicio Tabela-->
    <div class="x">

      <table border="1">
        <thead>
          <tr>
            <td>Cód.</td>
            <td>Nome</td>
            <td>#</td>
          </tr>
        </thead>
        <tbody>
          <?php
         
          if (isset($_GET['excluir'])) {
           ExcluirEditora($_GET['excluir']); 
          }
    
          $registros = ListarEditora(0);
          while ($editora = $registros ->fetch_array()){
              echo'<tr>
               
                <td>'.$editora['cd_editora'].'</td>
                <td>'.$editora['nm_editora'].'</td>
                
                <td> 
                <button name="" class="btn btn-default btn-block" style="background-color: yellow" class ="editar" value ="'.$editora['cd_editora'].'">Editar</button>
                </td>

                <td>
               <button name="" class="btn btn-default btn-block" style="background-color: red" > <a href ="?excluir='.$editora['cd_editora'].'">Excluir</a></button>
                </td>


              </tr>';
          }
          ?>

        </tbody>
      </table>
    </div>
    <!--Fim Tabela-->

</div>


    </div>


    <script type="text/javascript">
    $(document).ready(function(){
      $('.nav_btn').click(function(){
        $('.mobile_nav_items').toggleClass('active');
      });
    });


    $('#titulo2').click(function(){
      $('.titulo2')

    })


    </script>

  </body>
</html>
<?php 
}
?>