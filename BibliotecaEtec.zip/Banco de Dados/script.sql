create database biblioteca;

USE biblioteca;

CREATE TABLE tb_editora(
cd_editora INT PRIMARY KEY AUTO_INCREMENT,
nm_editora VARCHAR(45)
);