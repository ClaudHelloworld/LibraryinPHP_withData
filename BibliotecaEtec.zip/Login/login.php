<!DOCTYPE html>
<html>
<html lang="pt-BR" dir="ltr">

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">


</head>
<title>Login Screen</title>

<body>

<div class="login">
	<img src="img/pflogin.png" class="usuario" width="100"
	height="100" alt="">
	<h1>Login</h1>
	<form>		
		<p>Email:</p>
		<input type="text" name="email" placeholder="Insirra seu Email de Login" >
		<p>Senha</p>
		<input type="password" name="senha" placeholder="Sua Senha." >
		<br>
	    <a href="../ds/dashboard.php" button style="background: orange; border-radius: 6px; padding: 15px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Login</button></a>
	    <br>
		<br>
		<a href="#">Esqueceu sua senha?</a><br>
		<a href="#">Cadastre aqui.</a>	
	</form>
</div>


</body>
</html>